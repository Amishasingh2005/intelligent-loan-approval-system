# ============================================================
# app/streamlit_app.py
#
# PURPOSE: Streamlit web UI for Loan Approval System.
#
# FEATURES:
#   - Input form for applicant details
#   - Real-time ML prediction with probability gauge
#   - AI-powered explanation from RAG + LLM
#   - Feature risk breakdown
#   - Improvement suggestions
# ============================================================

import streamlit as st
import joblib
import numpy as np
import pandas as pd
import sys
import os

# Add project root to Python path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# ── PAGE CONFIG ───────────────────────────────────────────────────
st.set_page_config(
    page_title="🏦 Loan Approval AI",
    page_icon="🏦",
    layout="wide",
    initial_sidebar_state="expanded"
)

# ── CUSTOM CSS ────────────────────────────────────────────────────
st.markdown("""
<style>
    @import url('https://fonts.googleapis.com/css2?family=IBM+Plex+Sans:wght@300;400;500;600;700&family=IBM+Plex+Mono:wght@400;500&display=swap');

    html, body, [class*="css"] {
        font-family: 'IBM Plex Sans', sans-serif;
    }

    /* Header */
    .main-header {
        background: linear-gradient(135deg, #0f2027, #203a43, #2c5364);
        padding: 2rem 2.5rem;
        border-radius: 12px;
        margin-bottom: 2rem;
        border-left: 5px solid #00d2ff;
    }
    .main-header h1 { color: #ffffff; font-size: 2rem; margin: 0; }
    .main-header p  { color: #a8d8ea; margin: 0.5rem 0 0 0; font-size: 1rem; }

    /* Decision cards */
    .approved-card {
        background: linear-gradient(135deg, #0a3d2a, #1a5c3a);
        border: 2px solid #2ecc71;
        border-radius: 12px;
        padding: 1.5rem;
        text-align: center;
    }
    .rejected-card {
        background: linear-gradient(135deg, #3d0a0a, #5c1a1a);
        border: 2px solid #e74c3c;
        border-radius: 12px;
        padding: 1.5rem;
        text-align: center;
    }
    .decision-label { font-size: 1rem; color: #aaa; text-transform: uppercase; letter-spacing: 2px; }
    .decision-value { font-size: 3rem; font-weight: 700; margin: 0.3rem 0; }
    .decision-prob  { font-size: 1rem; color: #ddd; }

    /* Risk meter bars */
    .risk-bar-container { margin: 0.4rem 0; }
    .risk-label { font-size: 0.85rem; color: #888; margin-bottom: 2px; }

    /* Info box */
    .info-box {
        background: #1a2634;
        border-radius: 8px;
        padding: 1rem 1.2rem;
        border-left: 3px solid #3498db;
        margin: 0.5rem 0;
    }

    /* Metric cards */
    .metric-card {
        background: #1e2a38;
        border-radius: 10px;
        padding: 1rem;
        text-align: center;
        border: 1px solid #2c3e50;
    }
    .metric-value { font-size: 1.6rem; font-weight: 700; font-family: 'IBM Plex Mono', monospace; }
    .metric-label { font-size: 0.75rem; color: #888; text-transform: uppercase; letter-spacing: 1px; }

    /* Explanation box */
    .explanation-box {
        background: #141e2d;
        border-radius: 10px;
        padding: 1.5rem;
        border: 1px solid #2c3e50;
        font-size: 0.95rem;
        line-height: 1.7;
        white-space: pre-wrap;
    }

    /* Hide streamlit branding */
    #MainMenu {visibility: hidden;}
    footer {visibility: hidden;}

    .stButton > button {
        background: linear-gradient(135deg, #0066cc, #00aaff);
        color: white;
        border: none;
        border-radius: 8px;
        font-weight: 600;
        font-size: 1rem;
        padding: 0.6rem 1.5rem;
        width: 100%;
        transition: all 0.2s;
    }
    .stButton > button:hover {
        background: linear-gradient(135deg, #0055aa, #0099ee);
        transform: translateY(-1px);
        box-shadow: 0 4px 12px rgba(0,150,255,0.3);
    }
</style>
""", unsafe_allow_html=True)


# ── LOAD ML MODEL & ARTIFACTS ─────────────────────────────────────
@st.cache_resource
def load_model_artifacts():
    """Load ML model, scaler, and feature names (cached)."""
    try:
        model = joblib.load("models/loan_model.pkl")
        scaler = joblib.load("models/scaler.pkl")
        feature_names = joblib.load("models/feature_names.pkl")
        return model, scaler, feature_names, True
    except FileNotFoundError:
        return None, None, None, False


model, scaler, feature_names, models_loaded = load_model_artifacts()


# ── PREDICTION FUNCTION ───────────────────────────────────────────
def predict_loan(applicant: dict) -> dict:
    """Run ML prediction on applicant data."""

    # Employment encoding
    emp_map = {'Employed': 2, 'Self-Employed': 1, 'Unemployed': 0}

    # Build feature vector (must match training order)
    annual_income  = applicant['annual_income']
    credit_score   = applicant['credit_score']
    loan_amount    = applicant['loan_amount']
    loan_term      = applicant['loan_term_months']
    emp_encoded    = emp_map[applicant['employment_type']]
    years_emp      = applicant['years_employed']
    dependents     = applicant['num_dependents']
    existing_debt  = applicant['existing_debt']
    dti            = applicant['debt_to_income']
    collateral     = applicant['has_collateral']

    # Engineered features
    loan_to_income   = loan_amount / annual_income
    monthly_payment  = loan_amount / loan_term
    income_coverage  = min((annual_income / 12) / monthly_payment, 50)
    income_per_dep   = annual_income / (dependents + 1)

    if credit_score >= 800:    cs_band = 4
    elif credit_score >= 740:  cs_band = 3
    elif credit_score >= 670:  cs_band = 2
    elif credit_score >= 580:  cs_band = 1
    else:                      cs_band = 0

    # Feature vector in training order
    features = [
        annual_income, credit_score, loan_amount, loan_term,
        years_emp, dependents, existing_debt, dti, collateral,
        emp_encoded, loan_to_income, monthly_payment,
        income_coverage, income_per_dep, cs_band
    ]

    # Use feature_names order if available
    if feature_names:
        feature_dict = {
            'annual_income': annual_income, 'credit_score': credit_score,
            'loan_amount': loan_amount, 'loan_term_months': loan_term,
            'years_employed': years_emp, 'num_dependents': dependents,
            'existing_debt': existing_debt, 'debt_to_income': dti,
            'has_collateral': collateral, 'employment_type_encoded': emp_encoded,
            'loan_to_income_ratio': loan_to_income, 'monthly_payment_est': monthly_payment,
            'income_monthly_coverage': income_coverage, 'income_per_dependent': income_per_dep,
            'credit_score_band': cs_band
        }
        features = [feature_dict.get(f, 0) for f in feature_names]

    X = np.array(features).reshape(1, -1)
    X_scaled = scaler.transform(X)

    pred = model.predict(X_scaled)[0]
    prob = model.predict_proba(X_scaled)[0][1]

    return {
        'approved': bool(pred),
        'prediction': 'Approved' if pred else 'Rejected',
        'probability': float(prob),
        'rejection_probability': float(1 - prob)
    }


def compute_risk_factors(applicant: dict) -> list:
    """Compute risk factor scores for display."""
    factors = []

    # Credit score risk
    cs = applicant['credit_score']
    cs_score = min(100, max(0, (cs - 300) / 5.5))
    factors.append(("Credit Score", cs_score, f"{cs}"))

    # DTI risk (lower = better, so invert)
    dti = applicant['debt_to_income']
    dti_score = max(0, 100 - dti * 180)
    factors.append(("Debt-to-Income", dti_score, f"{dti*100:.1f}%"))

    # Loan-to-income (lower = better)
    lti = applicant['loan_amount'] / applicant['annual_income']
    lti_score = max(0, 100 - lti * 18)
    factors.append(("Income Adequacy", lti_score, f"${applicant['annual_income']:,}"))

    # Employment
    emp_map = {'Employed': 90, 'Self-Employed': 60, 'Unemployed': 10}
    factors.append(("Employment", emp_map[applicant['employment_type']], applicant['employment_type']))

    # Collateral
    coll_score = 80 if applicant['has_collateral'] else 30
    factors.append(("Collateral", coll_score, "Yes" if applicant['has_collateral'] else "No"))

    return factors


# ── MAIN HEADER ───────────────────────────────────────────────────
st.markdown("""
<div class="main-header">
    <h1>🏦 AI Loan Approval & Advisory System</h1>
    <p>Machine Learning + Retrieval-Augmented Generation · Instant decisions with intelligent explanations</p>
</div>
""", unsafe_allow_html=True)

# ── MODEL STATUS CHECK ───────────────────────────────────────────
if not models_loaded:
    st.error("""
    ⚠️ **ML Model Not Found!** Please run the setup first:
    ```bash
    python data/generate_dataset.py
    python ml/train_model.py
    python rag/build_vectorstore.py
    ```
    """)
    st.stop()

# ── SIDEBAR — INPUT FORM ─────────────────────────────────────────
st.sidebar.markdown("## 📋 Applicant Information")
st.sidebar.markdown("Fill in the applicant's financial details below.")

with st.sidebar:
    st.markdown("### 💰 Financial Profile")
    annual_income = st.number_input(
        "Annual Income ($)", min_value=10_000, max_value=1_000_000,
        value=65_000, step=5_000, help="Total yearly income before taxes"
    )
    credit_score = st.slider(
        "Credit Score (FICO)", min_value=300, max_value=850,
        value=700, help="300=Poor | 580=Fair | 670=Good | 740=VGood | 800=Excellent"
    )
    existing_debt = st.number_input(
        "Existing Debt ($)", min_value=0, max_value=500_000,
        value=15_000, step=1_000, help="Total outstanding debt"
    )

    st.markdown("### 🏠 Loan Details")
    loan_amount = st.number_input(
        "Loan Amount ($)", min_value=5_000, max_value=1_000_000,
        value=120_000, step=5_000
    )
    loan_term = st.selectbox(
        "Loan Term", options=[12, 24, 36, 60],
        index=2, format_func=lambda x: f"{x} months ({x//12} yr)" if x >= 12 else f"{x} months"
    )
    has_collateral = st.checkbox("Has Collateral", value=True,
                                  help="Property, vehicle, or other security")

    st.markdown("### 👤 Personal Details")
    employment_type = st.selectbox(
        "Employment Type", options=["Employed", "Self-Employed", "Unemployed"]
    )
    years_employed = st.number_input(
        "Years Employed", min_value=0, max_value=40,
        value=4
    )
    num_dependents = st.number_input(
        "Number of Dependents", min_value=0, max_value=10,
        value=1
    )

    st.markdown("### 🤖 LLM Settings")
    llm_choice = st.selectbox(
        "Explanation Engine",
        options=["groq", "openai", "rules"],
        help="groq=Free & Fast | openai=GPT-4 | rules=No API needed"
    )

    st.markdown("---")
    predict_button = st.button("🔍 Analyze Loan Application", use_container_width=True)


# ── MAIN CONTENT ──────────────────────────────────────────────────

# Auto-compute DTI
dti = round(existing_debt / annual_income, 2) if annual_income > 0 else 0

# Show quick stats in columns
col1, col2, col3, col4 = st.columns(4)
with col1:
    st.markdown(f"""<div class="metric-card">
        <div class="metric-value" style="color:#3498db">${annual_income:,}</div>
        <div class="metric-label">Annual Income</div></div>""", unsafe_allow_html=True)
with col2:
    cs_color = "#2ecc71" if credit_score >= 700 else "#f39c12" if credit_score >= 580 else "#e74c3c"
    st.markdown(f"""<div class="metric-card">
        <div class="metric-value" style="color:{cs_color}">{credit_score}</div>
        <div class="metric-label">Credit Score</div></div>""", unsafe_allow_html=True)
with col3:
    dti_color = "#2ecc71" if dti < 0.36 else "#f39c12" if dti < 0.43 else "#e74c3c"
    st.markdown(f"""<div class="metric-card">
        <div class="metric-value" style="color:{dti_color}">{dti*100:.1f}%</div>
        <div class="metric-label">Debt-to-Income Ratio</div></div>""", unsafe_allow_html=True)
with col4:
    lti = round(loan_amount / annual_income, 2)
    lti_color = "#2ecc71" if lti < 3 else "#f39c12" if lti < 5 else "#e74c3c"
    st.markdown(f"""<div class="metric-card">
        <div class="metric-value" style="color:{lti_color}">{lti:.1f}x</div>
        <div class="metric-label">Loan-to-Income Ratio</div></div>""", unsafe_allow_html=True)

st.markdown("<br>", unsafe_allow_html=True)

# ── PREDICTION RESULTS ────────────────────────────────────────────
if predict_button:
    applicant = {
        "annual_income": annual_income,
        "credit_score": credit_score,
        "loan_amount": loan_amount,
        "loan_term_months": loan_term,
        "employment_type": employment_type,
        "years_employed": years_employed,
        "num_dependents": num_dependents,
        "existing_debt": existing_debt,
        "debt_to_income": dti,
        "has_collateral": int(has_collateral)
    }

    with st.spinner("🤖 Analyzing application..."):
        result = predict_loan(applicant)

    # ── Decision Card ──────────────────────────────────────────
    col_dec, col_risk = st.columns([1, 1])

    with col_dec:
        if result['approved']:
            st.markdown(f"""
            <div class="approved-card">
                <div class="decision-label">Loan Decision</div>
                <div class="decision-value" style="color:#2ecc71">✅ APPROVED</div>
                <div class="decision-prob">Approval Confidence: {result['probability']*100:.1f}%</div>
            </div>""", unsafe_allow_html=True)
        else:
            st.markdown(f"""
            <div class="rejected-card">
                <div class="decision-label">Loan Decision</div>
                <div class="decision-value" style="color:#e74c3c">❌ REJECTED</div>
                <div class="decision-prob">Rejection Confidence: {result['rejection_probability']*100:.1f}%</div>
            </div>""", unsafe_allow_html=True)

        # Probability bar
        st.markdown("<br>", unsafe_allow_html=True)
        prob_pct = result['probability'] * 100
        bar_color = "#2ecc71" if result['approved'] else "#e74c3c"
        st.markdown(f"**Approval Probability**: {prob_pct:.1f}%")
        st.progress(result['probability'])

    with col_risk:
        st.markdown("**📊 Risk Factor Analysis**")
        factors = compute_risk_factors(applicant)

        for name, score, value in factors:
            bar_color = "🟢" if score >= 70 else "🟡" if score >= 40 else "🔴"
            st.markdown(f"{bar_color} **{name}**: {value}")
            st.progress(score / 100)

    # ── RAG + LLM Explanation ──────────────────────────────────
    st.markdown("<br>", unsafe_allow_html=True)
    st.markdown("### 🤖 AI Financial Advisory Explanation")

    with st.spinner("📚 Retrieving financial guidelines & generating explanation..."):
        try:
            from llm.explainer import generate_explanation
            explanation_result = generate_explanation(
                applicant, result['prediction'], result['probability'], use_llm=llm_choice
            )
            explanation_text = explanation_result['explanation']
        except Exception as e:
            explanation_text = (
                f"**{result['prediction']}** — Confidence: {result['probability']*100:.1f}%\n\n"
                f"Note: Full AI explanation unavailable ({str(e)[:100)}).\n"
                f"Please ensure the vector store is built and an LLM API key is configured."
            )

    st.markdown(f"""<div class="explanation-box">{explanation_text}</div>""",
                unsafe_allow_html=True)

    # ── Raw Data Expandable ────────────────────────────────────
    with st.expander("🔬 View Technical Details"):
        st.markdown("**Applicant Data Submitted:**")
        st.json(applicant)
        st.markdown(f"**ML Prediction:** `{result['prediction']}` | **Probability:** `{result['probability']:.4f}`")

else:
    # Default state — instructions
    st.info("👈 **Fill in the applicant details in the sidebar and click 'Analyze Loan Application'** to get an AI-powered loan decision with explanation.")

    st.markdown("### 📌 How This System Works")
    col1, col2, col3 = st.columns(3)

    with col1:
        st.markdown("""
        **🤖 ML Prediction**
        
        A Random Forest model trained on 2,000 loan applications analyzes credit score, income, debt ratio, employment status, and more to predict approval/rejection.
        """)
    with col2:
        st.markdown("""
        **🔍 RAG Knowledge Retrieval**
        
        The system searches a FAISS vector database of financial guidelines to find the most relevant rules for your specific profile.
        """)
    with col3:
        st.markdown("""
        **💬 AI Explanation**
        
        An LLM (Llama3/GPT-4) combines the ML decision and retrieved guidelines to generate a clear, grounded explanation — no hallucination.
        """)

    st.markdown("### 🧪 Try These Example Inputs")
    examples = pd.DataFrame([
        {"Income": "$85,000", "Credit Score": 750, "Loan": "$150,000", "DTI": "24%", "Employment": "Employed", "Expected": "✅ Approved"},
        {"Income": "$25,000", "Credit Score": 520, "Loan": "$300,000", "DTI": "72%", "Employment": "Unemployed", "Expected": "❌ Rejected"},
        {"Income": "$60,000", "Credit Score": 680, "Loan": "$140,000", "DTI": "38%", "Employment": "Employed", "Expected": "✅ Approved"},
        {"Income": "$35,000", "Credit Score": 490, "Loan": "$450,000", "DTI": "61%", "Employment": "Self-Employed", "Expected": "❌ Rejected"},
    ])
    st.dataframe(examples, use_container_width=True, hide_index=True)
