# 🏦 Loan Approval & Financial Advisory System
## ML + RAG End-to-End Project

---

## 📁 Project Structure

```
loan_approval_rag/
├── README.md                    ← You are here
├── requirements.txt             ← All dependencies
├── data/
│   └── generate_dataset.py      ← Generates sample loan dataset
├── ml/
│   ├── preprocess.py            ← Data cleaning & feature engineering
│   └── train_model.py           ← Train & evaluate ML model
├── rag/
│   ├── knowledge_base.py        ← Financial rules text documents
│   ├── build_vectorstore.py     ← Chunking + embeddings + FAISS
│   └── retriever.py             ← Query the vector store
├── llm/
│   └── explainer.py             ← Combine ML + RAG → LLM explanation
├── app/
│   └── streamlit_app.py         ← Streamlit UI
└── models/                      ← Saved ML model & FAISS index (auto-created)
```

---

## 🚀 How to Run Locally

### Step 1: Install Dependencies
```bash
pip install -r requirements.txt
```

### Step 2: Generate Dataset
```bash
python data/generate_dataset.py
```

### Step 3: Train ML Model
```bash
python ml/train_model.py
```

### Step 4: Build RAG Vector Store
```bash
python rag/build_vectorstore.py
```

### Step 5: Launch Streamlit App
```bash
streamlit run app/streamlit_app.py
```

---

## 🧪 Example Test Inputs

| Income  | Credit Score | Loan Amount | Employment | Debt Ratio | Expected  |
|---------|-------------|-------------|------------|------------|-----------|
| 80,000  | 750         | 200,000     | Employed   | 0.25       | ✅ Approved |
| 25,000  | 550         | 300,000     | Unemployed | 0.70       | ❌ Rejected |
| 60,000  | 680         | 150,000     | Employed   | 0.40       | ✅ Approved |
| 35,000  | 490         | 500,000     | Self-Emp   | 0.60       | ❌ Rejected |

---

## 🔑 API Key Setup (for LLM)
Set your OpenAI or Groq API key as environment variable:
```bash
export OPENAI_API_KEY="your-key-here"
# OR use Groq (free):
export GROQ_API_KEY="your-key-here"
```
