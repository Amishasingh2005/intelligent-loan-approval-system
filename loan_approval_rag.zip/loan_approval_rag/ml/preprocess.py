# ============================================================
# ml/preprocess.py
#
# PURPOSE: Clean raw loan data and engineer useful features.
#
# STEPS:
#   1. Handle missing values (imputation)
#   2. Remove outliers
#   3. Encode categorical columns
#   4. Feature engineering (new derived columns)
#   5. Scale numerical features
#   6. Return train/test splits ready for modeling
# ============================================================

import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.impute import SimpleImputer
import joblib
import os


def load_data(filepath: str = "data/loan_data.csv") -> pd.DataFrame:
    """Load raw CSV dataset."""
    df = pd.read_csv(filepath)
    print(f"📂 Loaded data: {df.shape[0]} rows, {df.shape[1]} columns")
    return df


def handle_missing_values(df: pd.DataFrame) -> pd.DataFrame:
    """
    Fill missing values using appropriate strategies:
    - Numerical columns → fill with MEDIAN (robust to outliers)
    - Categorical columns → fill with MODE (most frequent value)
    """
    print("🔧 Handling missing values...")

    numerical_cols = df.select_dtypes(include=[np.number]).columns.tolist()
    categorical_cols = df.select_dtypes(include=['object']).columns.tolist()

    # Remove target from numerical list
    if 'loan_approved' in numerical_cols:
        numerical_cols.remove('loan_approved')

    # Impute numerical with median
    num_imputer = SimpleImputer(strategy='median')
    df[numerical_cols] = num_imputer.fit_transform(df[numerical_cols])

    # Impute categorical with most frequent
    for col in categorical_cols:
        df[col].fillna(df[col].mode()[0], inplace=True)

    print(f"   Missing values after imputation: {df.isnull().sum().sum()}")
    return df


def remove_outliers(df: pd.DataFrame) -> pd.DataFrame:
    """
    Remove extreme outliers using IQR (Interquartile Range) method.
    
    IQR Method:
    - Q1 = 25th percentile, Q3 = 75th percentile
    - IQR = Q3 - Q1
    - Outlier if value < Q1 - 1.5×IQR  OR  > Q3 + 1.5×IQR
    
    We only apply this to key financial columns, not all columns.
    """
    print("🔧 Removing outliers...")

    outlier_cols = ['annual_income', 'loan_amount', 'existing_debt']
    initial_rows = len(df)

    for col in outlier_cols:
        Q1 = df[col].quantile(0.25)
        Q3 = df[col].quantile(0.75)
        IQR = Q3 - Q1
        lower = Q1 - 1.5 * IQR
        upper = Q3 + 1.5 * IQR
        df = df[(df[col] >= lower) & (df[col] <= upper)]

    print(f"   Rows before: {initial_rows} → after: {len(df)} (removed {initial_rows - len(df)})")
    return df.reset_index(drop=True)


def encode_categorical(df: pd.DataFrame) -> pd.DataFrame:
    """
    Convert text columns to numbers so ML models can process them.
    
    employment_type: 'Employed'→2, 'Self-Employed'→1, 'Unemployed'→0
    (We use Label Encoding here; One-Hot is another valid option)
    """
    print("🔧 Encoding categorical features...")

    le = LabelEncoder()
    df['employment_type_encoded'] = le.fit_transform(df['employment_type'])

    # Save label encoder for use in the app later
    os.makedirs("models", exist_ok=True)
    joblib.dump(le, "models/label_encoder.pkl")

    # Drop original text column
    df.drop(columns=['employment_type'], inplace=True)

    return df


def feature_engineering(df: pd.DataFrame) -> pd.DataFrame:
    """
    Create NEW features that give the ML model more signal:
    
    - loan_to_income_ratio   : loan ÷ income (affordability check)
    - monthly_payment_est    : rough monthly payment estimate
    - income_per_dependent   : income spread across dependents
    - credit_score_band      : categorical bucket for credit score
    """
    print("🔧 Engineering new features...")

    # Loan-to-income ratio: high ratio = risky
    df['loan_to_income_ratio'] = df['loan_amount'] / df['annual_income']

    # Estimated monthly payment (simple approximation)
    df['monthly_payment_est'] = df['loan_amount'] / df['loan_term_months']

    # Monthly income coverage: how many times income covers payment
    df['income_monthly_coverage'] = (df['annual_income'] / 12) / df['monthly_payment_est']
    df['income_monthly_coverage'] = df['income_monthly_coverage'].clip(0, 50)  # cap extremes

    # Income per dependent: lower → more financial stress
    df['income_per_dependent'] = df['annual_income'] / (df['num_dependents'] + 1)

    # Credit score buckets (helps model capture non-linearity)
    df['credit_score_band'] = pd.cut(
        df['credit_score'],
        bins=[0, 580, 670, 740, 800, 850],
        labels=[0, 1, 2, 3, 4]   # 0=Poor, 1=Fair, 2=Good, 3=VGood, 4=Excellent
    ).astype(int)

    print(f"   Features after engineering: {df.shape[1]}")
    return df


def preprocess_pipeline(filepath: str = "data/loan_data.csv"):
    """
    Full preprocessing pipeline.
    Returns: X_train, X_test, y_train, y_test, feature_names, scaler
    """
    # Load
    df = load_data(filepath)

    # Clean
    df = handle_missing_values(df)
    df = remove_outliers(df)
    df = encode_categorical(df)
    df = feature_engineering(df)

    # Separate features (X) and target (y)
    target = 'loan_approved'
    feature_cols = [c for c in df.columns if c != target]
    
    X = df[feature_cols]
    y = df[target]

    print(f"\n📊 Class distribution:")
    print(f"   Approved: {y.sum()} ({y.mean()*100:.1f}%)")
    print(f"   Rejected: {(y==0).sum()} ({(1-y.mean())*100:.1f}%)")

    # Train-test split (80/20, stratified to keep class balance)
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.20, random_state=42, stratify=y
    )

    # Scale features (zero mean, unit variance)
    # Important: fit ONLY on train data, transform both
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled  = scaler.transform(X_test)

    # Save scaler for the Streamlit app
    os.makedirs("models", exist_ok=True)
    joblib.dump(scaler, "models/scaler.pkl")
    joblib.dump(list(feature_cols), "models/feature_names.pkl")

    print(f"\n✅ Preprocessing complete!")
    print(f"   Train size : {X_train_scaled.shape}")
    print(f"   Test size  : {X_test_scaled.shape}")

    return X_train_scaled, X_test_scaled, y_train, y_test, list(feature_cols), scaler


if __name__ == "__main__":
    preprocess_pipeline()
