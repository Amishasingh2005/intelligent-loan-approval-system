# ============================================================
# ml/train_model.py
#
# PURPOSE: Train a Random Forest classifier on loan data,
#          evaluate it with proper metrics, and save the model.
#
# WHY RANDOM FOREST?
#   ✅ Works well with mixed data (numbers + categories)
#   ✅ Handles non-linear relationships
#   ✅ Gives feature importance (which factors matter most)
#   ✅ Robust to outliers
#   ✅ Generally outperforms Logistic Regression on tabular data
# ============================================================

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import joblib
import os

from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score,
    f1_score, roc_auc_score, confusion_matrix,
    classification_report, roc_curve
)

# Import our preprocessing pipeline
import sys
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from ml.preprocess import preprocess_pipeline


def train_random_forest(X_train, y_train) -> RandomForestClassifier:
    """
    Train a Random Forest classifier.
    
    Key hyperparameters:
    - n_estimators   : Number of trees (more = more stable but slower)
    - max_depth      : How deep each tree grows (limits overfitting)
    - min_samples_split: Min samples needed to split a node
    - class_weight   : 'balanced' handles class imbalance automatically
    """
    print("\n🌳 Training Random Forest...")

    model = RandomForestClassifier(
        n_estimators=200,         # 200 trees for stability
        max_depth=8,              # Prevent overfitting
        min_samples_split=10,     # Need 10 samples to split
        min_samples_leaf=5,       # Each leaf needs ≥5 samples
        max_features='sqrt',      # Use sqrt(features) per tree
        class_weight='balanced',  # Handle class imbalance
        random_state=42,
        n_jobs=-1                 # Use all CPU cores
    )

    model.fit(X_train, y_train)
    print("   ✅ Training complete!")
    return model


def evaluate_model(model, X_test, y_test, feature_names: list, model_name: str = "Random Forest"):
    """
    Comprehensive model evaluation.
    
    Metrics explained:
    - Accuracy   : % of ALL predictions correct (misleading if imbalanced)
    - Precision  : Of predicted "Approved", how many truly were? (avoid false approvals)
    - Recall     : Of truly "Approved", how many did we catch? (avoid missing good applicants)
    - F1-Score   : Harmonic mean of Precision & Recall (best single metric)
    - AUC-ROC    : Area under ROC curve (model's ranking ability, 0.5=random, 1.0=perfect)
    """
    print(f"\n📊 Evaluating {model_name}...")

    y_pred = model.predict(X_test)
    y_proba = model.predict_proba(X_test)[:, 1]  # Probability of approval

    # Core metrics
    accuracy  = accuracy_score(y_test, y_pred)
    precision = precision_score(y_test, y_pred)
    recall    = recall_score(y_test, y_pred)
    f1        = f1_score(y_test, y_pred)
    auc_roc   = roc_auc_score(y_test, y_proba)

    print(f"\n{'='*45}")
    print(f"  {model_name} — Evaluation Results")
    print(f"{'='*45}")
    print(f"  Accuracy  : {accuracy:.4f}  ({accuracy*100:.1f}%)")
    print(f"  Precision : {precision:.4f}")
    print(f"  Recall    : {recall:.4f}")
    print(f"  F1-Score  : {f1:.4f}")
    print(f"  AUC-ROC   : {auc_roc:.4f}")
    print(f"{'='*45}")

    print(f"\n  Classification Report:")
    print(classification_report(y_test, y_pred, target_names=['Rejected', 'Approved']))

    # ── Confusion Matrix Plot ──────────────────────────────────
    os.makedirs("models", exist_ok=True)

    fig, axes = plt.subplots(1, 2, figsize=(14, 5))

    # Confusion matrix
    cm = confusion_matrix(y_test, y_pred)
    sns.heatmap(
        cm, annot=True, fmt='d', cmap='Blues',
        xticklabels=['Rejected', 'Approved'],
        yticklabels=['Rejected', 'Approved'],
        ax=axes[0], linewidths=1, linecolor='white'
    )
    axes[0].set_title('Confusion Matrix', fontsize=13, fontweight='bold')
    axes[0].set_ylabel('Actual', fontsize=11)
    axes[0].set_xlabel('Predicted', fontsize=11)

    # ROC Curve
    fpr, tpr, _ = roc_curve(y_test, y_proba)
    axes[1].plot(fpr, tpr, 'b-', lw=2, label=f'AUC = {auc_roc:.3f}')
    axes[1].plot([0, 1], [0, 1], 'k--', lw=1, label='Random Classifier')
    axes[1].fill_between(fpr, tpr, alpha=0.1, color='blue')
    axes[1].set_xlabel('False Positive Rate', fontsize=11)
    axes[1].set_ylabel('True Positive Rate', fontsize=11)
    axes[1].set_title('ROC Curve', fontsize=13, fontweight='bold')
    axes[1].legend(loc='lower right')
    axes[1].grid(True, alpha=0.3)

    plt.tight_layout()
    plt.savefig("models/evaluation_plots.png", dpi=150, bbox_inches='tight')
    plt.close()
    print("\n  📈 Evaluation plots saved → models/evaluation_plots.png")

    # ── Feature Importance Plot ────────────────────────────────
    if hasattr(model, 'feature_importances_'):
        importance_df = pd.DataFrame({
            'feature': feature_names,
            'importance': model.feature_importances_
        }).sort_values('importance', ascending=True)

        fig, ax = plt.subplots(figsize=(10, 7))
        colors = ['#2ecc71' if i >= len(importance_df)-5 else '#3498db'
                  for i in range(len(importance_df))]
        bars = ax.barh(importance_df['feature'], importance_df['importance'],
                       color=colors, edgecolor='white')
        ax.set_xlabel('Importance Score', fontsize=11)
        ax.set_title('Feature Importance — Which Factors Drive Loan Decisions?',
                     fontsize=12, fontweight='bold')
        ax.axvline(x=0.05, color='red', linestyle='--', alpha=0.5, label='5% threshold')
        ax.legend()
        plt.tight_layout()
        plt.savefig("models/feature_importance.png", dpi=150, bbox_inches='tight')
        plt.close()
        print("  📈 Feature importance plot saved → models/feature_importance.png")

        print(f"\n  Top 5 Most Important Features:")
        top5 = importance_df.tail(5)[::-1]
        for _, row in top5.iterrows():
            bar = "█" * int(row['importance'] * 100)
            print(f"    {row['feature']:<30} {bar} {row['importance']:.3f}")

    return {
        'accuracy': accuracy, 'precision': precision,
        'recall': recall, 'f1': f1, 'auc_roc': auc_roc
    }


def predict_single(model, scaler, feature_names: list, input_data: dict) -> dict:
    """
    Make a prediction for a SINGLE applicant.
    
    Args:
        input_data: dict with applicant details
    Returns:
        dict with prediction, probability, and key risk factors
    """
    # Build a DataFrame with feature engineering applied
    from ml.preprocess import feature_engineering, encode_categorical
    import pandas as pd

    df = pd.DataFrame([input_data])

    # Apply same transformations as training
    # employment encoding
    employment_map = {'Employed': 2, 'Self-Employed': 1, 'Unemployed': 0}
    df['employment_type_encoded'] = df['employment_type'].map(employment_map)
    df.drop(columns=['employment_type'], inplace=True)

    # Feature engineering
    df['loan_to_income_ratio']   = df['loan_amount'] / df['annual_income']
    df['monthly_payment_est']    = df['loan_amount'] / df['loan_term_months']
    df['income_monthly_coverage'] = (df['annual_income'] / 12) / df['monthly_payment_est']
    df['income_monthly_coverage'] = df['income_monthly_coverage'].clip(0, 50)
    df['income_per_dependent']   = df['annual_income'] / (df['num_dependents'] + 1)
    df['credit_score_band']      = pd.cut(
        df['credit_score'], bins=[0, 580, 670, 740, 800, 850], labels=[0, 1, 2, 3, 4]
    ).astype(int)

    # Ensure column order matches training
    df = df[feature_names]

    # Scale
    X_scaled = scaler.transform(df)

    # Predict
    prediction = model.predict(X_scaled)[0]
    probability = model.predict_proba(X_scaled)[0][1]  # P(Approved)

    return {
        'prediction': 'Approved' if prediction == 1 else 'Rejected',
        'approved': bool(prediction),
        'probability': float(probability),
        'confidence': f"{max(probability, 1-probability)*100:.1f}%"
    }


def run_training_pipeline():
    """Main entry point — run full training pipeline."""

    print("=" * 55)
    print("  🏦 LOAN APPROVAL ML TRAINING PIPELINE")
    print("=" * 55)

    # Step 1: Preprocess
    X_train, X_test, y_train, y_test, feature_names, scaler = preprocess_pipeline()

    # Step 2: Train model
    model = train_random_forest(X_train, y_train)

    # Step 3: Evaluate
    metrics = evaluate_model(model, X_test, y_test, feature_names)

    # Step 4: Save model
    os.makedirs("models", exist_ok=True)
    joblib.dump(model, "models/loan_model.pkl")
    print(f"\n💾 Model saved → models/loan_model.pkl")

    # Step 5: Quick sanity check prediction
    print("\n🧪 Sanity Check — Predicting sample applicants:")
    test_cases = [
        {
            "label": "Strong applicant",
            "annual_income": 85000, "credit_score": 750, "loan_amount": 150000,
            "loan_term_months": 36, "employment_type": "Employed", "years_employed": 8,
            "num_dependents": 1, "existing_debt": 20000, "debt_to_income": 0.24,
            "has_collateral": 1
        },
        {
            "label": "Weak applicant",
            "annual_income": 22000, "credit_score": 520, "loan_amount": 400000,
            "loan_term_months": 36, "employment_type": "Unemployed", "years_employed": 0,
            "num_dependents": 3, "existing_debt": 18000, "debt_to_income": 0.82,
            "has_collateral": 0
        }
    ]

    for case in test_cases:
        label = case.pop("label")
        result = predict_single(model, scaler, feature_names, case)
        emoji = "✅" if result['approved'] else "❌"
        print(f"   {emoji} {label}: {result['prediction']} (P={result['probability']:.2f})")

    print("\n🎉 Training pipeline complete! Files saved in models/")
    return model, scaler, feature_names, metrics


if __name__ == "__main__":
    run_training_pipeline()
