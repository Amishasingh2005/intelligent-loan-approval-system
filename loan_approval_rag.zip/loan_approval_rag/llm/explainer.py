# ============================================================
# llm/explainer.py
#
# PURPOSE: Combine ML prediction + RAG context → LLM explanation
#
# FLOW:
#   1. Receive applicant data + ML prediction
#   2. Build query from applicant profile
#   3. Retrieve relevant financial guidelines (RAG)
#   4. Build structured prompt for LLM
#   5. Call LLM API (Groq or OpenAI)
#   6. Return clear, grounded explanation
#
# ANTI-HALLUCINATION STRATEGY:
#   - LLM is instructed to ONLY use provided data and context
#   - Prompt explicitly bans inventing facts or numbers
#   - Retrieved context grounds all claims in real financial rules
# ============================================================

import os
import sys

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from rag.retriever import build_context_string, build_query_from_application


def build_explanation_prompt(
    applicant_data: dict,
    prediction: str,
    probability: float,
    rag_context: str
) -> str:
    """
    Build a structured prompt that:
    1. Tells the LLM its role (financial advisor)
    2. Provides applicant data (no invention allowed)
    3. Provides retrieved financial guidelines (grounding)
    4. Tells LLM exactly what to output
    5. Explicitly prevents hallucination
    """

    # Format applicant data as readable text
    credit_band = (
        "Exceptional (800+)" if applicant_data['credit_score'] >= 800 else
        "Very Good (740-799)" if applicant_data['credit_score'] >= 740 else
        "Good (670-739)" if applicant_data['credit_score'] >= 670 else
        "Fair (580-669)" if applicant_data['credit_score'] >= 580 else
        "Poor (below 580)"
    )

    dti_band = (
        "Excellent (below 28%)" if applicant_data['debt_to_income'] < 0.28 else
        "Acceptable (28-36%)" if applicant_data['debt_to_income'] < 0.36 else
        "Borderline (36-43%)" if applicant_data['debt_to_income'] < 0.43 else
        "High Risk (above 43%)"
    )

    applicant_summary = f"""
APPLICANT DATA:
- Annual Income: ${applicant_data['annual_income']:,}
- Credit Score: {applicant_data['credit_score']} ({credit_band})
- Loan Amount Requested: ${applicant_data['loan_amount']:,}
- Loan Term: {applicant_data['loan_term_months']} months
- Employment Status: {applicant_data['employment_type']}
- Years Employed: {applicant_data.get('years_employed', 'N/A')}
- Number of Dependents: {applicant_data['num_dependents']}
- Existing Debt: ${applicant_data['existing_debt']:,}
- Debt-to-Income Ratio: {applicant_data['debt_to_income']*100:.1f}% ({dti_band})
- Has Collateral: {'Yes' if applicant_data['has_collateral'] else 'No'}

ML MODEL DECISION: {prediction}
Approval Probability: {probability*100:.1f}%
"""

    prompt = f"""You are a knowledgeable and empathetic bank loan advisor. Your role is to explain 
loan decisions clearly and provide helpful, actionable advice.

STRICT RULES YOU MUST FOLLOW:
1. ONLY use the applicant data and financial guidelines provided below.
2. Do NOT invent numbers, rates, or facts not present in the provided information.
3. Be specific — reference the actual values from the applicant's profile.
4. Be empathetic but professional in tone.
5. Structure your response clearly with sections.

{applicant_summary}

RELEVANT FINANCIAL GUIDELINES (retrieved from knowledge base):
{rag_context}

YOUR TASK:
Write a loan decision explanation with these sections:

**Decision Summary**
State the decision ({prediction}) clearly in 1-2 sentences with the confidence level.

**Key Factors in This Decision**
List 3-5 specific factors from the applicant's profile that most influenced the decision.
Reference actual numbers from the applicant data.

**Risk Analysis**
{"Explain which specific metrics raised concerns and why." if prediction == "Rejected" else "Explain which metrics demonstrated the applicant's creditworthiness."}

**Recommendations**
{"Provide 3-4 specific, actionable steps to improve their application in the future." if prediction == "Rejected" else "Provide advice on managing the loan responsibly."}

**Important Note**
Remind the applicant that this is an AI-assisted assessment and they should speak with a human loan officer for final decisions.

Write naturally, be specific with the numbers, and keep the total response under 400 words.
"""

    return prompt


def explain_with_groq(prompt: str) -> str:
    """
    Call Groq API (FREE, fast LLM).
    Get your free key at: https://console.groq.com
    
    Groq provides fast inference on open-source models like Llama3.
    """
    try:
        from groq import Groq

        api_key = os.getenv("GROQ_API_KEY")
        if not api_key:
            return _fallback_explanation()

        client = Groq(api_key=api_key)
        response = client.chat.completions.create(
            model="llama3-8b-8192",      # Fast, free, capable model
            messages=[
                {
                    "role": "system",
                    "content": "You are a professional bank loan advisor. Be clear, specific, and helpful."
                },
                {
                    "role": "user",
                    "content": prompt
                }
            ],
            max_tokens=600,
            temperature=0.3  # Low temperature = more factual, less creative
        )
        return response.choices[0].message.content

    except Exception as e:
        print(f"⚠️  Groq API error: {e}")
        return _fallback_explanation()


def explain_with_openai(prompt: str) -> str:
    """
    Call OpenAI API (GPT-4o-mini — cheaper option).
    Get your key at: https://platform.openai.com
    """
    try:
        from openai import OpenAI

        api_key = os.getenv("OPENAI_API_KEY")
        if not api_key:
            return _fallback_explanation()

        client = OpenAI(api_key=api_key)
        response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {
                    "role": "system",
                    "content": "You are a professional bank loan advisor. Be clear, specific, and helpful."
                },
                {
                    "role": "user",
                    "content": prompt
                }
            ],
            max_tokens=600,
            temperature=0.3
        )
        return response.choices[0].message.content

    except Exception as e:
        print(f"⚠️  OpenAI API error: {e}")
        return _fallback_explanation()


def _fallback_explanation() -> str:
    """
    Rule-based fallback when no LLM API key is available.
    Uses pure logic — zero hallucination possible.
    """
    return (
        "**Note**: LLM explanation unavailable (no API key configured).\n\n"
        "To enable AI-powered explanations:\n"
        "1. Get a free Groq API key at https://console.groq.com\n"
        "2. Set environment variable: `export GROQ_API_KEY=your_key`\n"
        "3. Or set `export OPENAI_API_KEY=your_key` for OpenAI GPT\n\n"
        "The ML prediction above is still valid and based on your input data."
    )


def generate_explanation(
    applicant_data: dict,
    prediction: str,
    probability: float,
    use_llm: str = "groq"   # "groq", "openai", or "rules"
) -> dict:
    """
    Main function: Generate a complete explanation for a loan decision.
    
    Args:
        applicant_data : Dict with all applicant fields
        prediction     : 'Approved' or 'Rejected'
        probability    : Float, probability of approval (0 to 1)
        use_llm        : Which LLM to use ('groq', 'openai', 'rules')
    
    Returns:
        dict with 'explanation' (str) and 'context_used' (list of chunks)
    """

    # Step 1: Build a smart query from the applicant profile
    query = build_query_from_application(applicant_data, prediction)

    # Step 2: Retrieve relevant financial guidelines (RAG)
    rag_context = build_context_string(query, top_k=4)

    # Step 3: Build structured prompt
    prompt = build_explanation_prompt(applicant_data, prediction, probability, rag_context)

    # Step 4: Call LLM
    if use_llm == "groq":
        explanation = explain_with_groq(prompt)
    elif use_llm == "openai":
        explanation = explain_with_openai(prompt)
    else:
        explanation = _fallback_explanation()

    return {
        'explanation': explanation,
        'rag_context': rag_context,
        'query_used': query,
        'prompt': prompt  # Useful for debugging
    }


if __name__ == "__main__":
    # Test with a sample rejected applicant
    test_applicant = {
        "annual_income": 28000,
        "credit_score": 510,
        "loan_amount": 300000,
        "loan_term_months": 36,
        "employment_type": "Unemployed",
        "years_employed": 0,
        "num_dependents": 2,
        "existing_debt": 20000,
        "debt_to_income": 0.71,
        "has_collateral": 0
    }

    print("🤖 Generating loan explanation...\n")
    result = generate_explanation(test_applicant, "Rejected", 0.12, use_llm="groq")

    print("RAG Context Retrieved:")
    print("-" * 40)
    print(result['rag_context'][:300] + "...")
    print("\nLLM Explanation:")
    print("=" * 40)
    print(result['explanation'])
