# ============================================================
# data/generate_dataset.py
#
# PURPOSE: Generates a realistic synthetic loan dataset with
#          features like income, credit score, loan amount, etc.
#          Saves it as data/loan_data.csv
#
# WHY SYNTHETIC? No sign-up or download needed. The dataset
# mimics real-world patterns so our ML model learns properly.
# ============================================================

import numpy as np
import pandas as pd
import os

# Set seed for reproducibility (same data every time you run)
np.random.seed(42)

def generate_loan_dataset(n_samples: int = 2000) -> pd.DataFrame:
    """
    Generate a synthetic but realistic loan dataset.
    
    Features:
    - annual_income     : Applicant's yearly income in USD
    - credit_score      : FICO score (300-850)
    - loan_amount       : Requested loan amount in USD
    - loan_term_months  : Duration to repay (12, 24, 36, 60 months)
    - employment_type   : Employed / Self-Employed / Unemployed
    - years_employed    : How long at current job
    - num_dependents    : Number of financial dependents
    - existing_debt     : Current outstanding debt in USD
    - debt_to_income    : Existing debt ÷ Annual income ratio
    - has_collateral    : Does applicant have collateral (Yes/No)
    - loan_approved     : TARGET — 1=Approved, 0=Rejected
    """

    # ── 1. Base applicant profiles ─────────────────────────────────
    annual_income = np.random.lognormal(mean=11.0, sigma=0.5, size=n_samples)
    annual_income = np.clip(annual_income, 15_000, 500_000).astype(int)

    credit_score = np.random.normal(loc=660, scale=80, size=n_samples)
    credit_score = np.clip(credit_score, 300, 850).astype(int)

    loan_amount = np.random.lognormal(mean=11.5, sigma=0.7, size=n_samples)
    loan_amount = np.clip(loan_amount, 5_000, 1_000_000).astype(int)

    loan_term = np.random.choice([12, 24, 36, 60], size=n_samples, p=[0.1, 0.2, 0.4, 0.3])

    employment_type = np.random.choice(
        ['Employed', 'Self-Employed', 'Unemployed'],
        size=n_samples,
        p=[0.65, 0.25, 0.10]
    )

    years_employed = np.where(
        employment_type == 'Unemployed',
        0,
        np.random.exponential(scale=5, size=n_samples).clip(0, 35).astype(int)
    )

    num_dependents = np.random.choice([0, 1, 2, 3, 4], size=n_samples, p=[0.3, 0.25, 0.25, 0.15, 0.05])

    existing_debt = (annual_income * np.random.uniform(0.05, 0.80, size=n_samples)).astype(int)

    debt_to_income = np.round(existing_debt / annual_income, 2)

    has_collateral = np.random.choice([1, 0], size=n_samples, p=[0.45, 0.55])

    # ── 2. Introduce realistic missing values (simulates real data) ─
    missing_mask_income = np.random.random(n_samples) < 0.02      # 2% missing
    missing_mask_credit = np.random.random(n_samples) < 0.03      # 3% missing
    missing_mask_years  = np.random.random(n_samples) < 0.05      # 5% missing

    annual_income_series = pd.Series(annual_income, dtype=float)
    credit_score_series  = pd.Series(credit_score, dtype=float)
    years_emp_series     = pd.Series(years_employed, dtype=float)

    annual_income_series[missing_mask_income] = np.nan
    credit_score_series[missing_mask_credit]  = np.nan
    years_emp_series[missing_mask_years]      = np.nan

    # ── 3. Business-logic approval rules ──────────────────────────
    # These rules mimic how real banks decide on loans:
    #   ✅ Credit score ≥ 650  → positive signal
    #   ✅ Debt-to-income ≤ 0.40 → manageable debt
    #   ✅ Income ≥ 3× monthly loan payment → can afford it
    #   ✅ Employed (not unemployed) → stable income
    #   ✅ Has collateral → reduced bank risk

    monthly_payment_approx = loan_amount / loan_term
    income_coverage = annual_income / 12 / monthly_payment_approx  # should be ≥ 3

    approval_score = (
        (credit_score >= 650).astype(int) * 30 +
        (debt_to_income <= 0.40).astype(int) * 25 +
        (income_coverage >= 3).astype(int) * 20 +
        (employment_type != 'Unemployed').astype(int) * 15 +
        (has_collateral == 1).astype(int) * 10
    )

    # Add some noise to prevent a perfect rule-based model
    noise = np.random.normal(0, 5, size=n_samples)
    approval_score = approval_score + noise

    # Threshold: ≥ 55 → Approved
    loan_approved = (approval_score >= 55).astype(int)

    # ── 4. Build DataFrame ─────────────────────────────────────────
    df = pd.DataFrame({
        'annual_income':    annual_income_series,
        'credit_score':     credit_score_series,
        'loan_amount':      loan_amount,
        'loan_term_months': loan_term,
        'employment_type':  employment_type,
        'years_employed':   years_emp_series,
        'num_dependents':   num_dependents,
        'existing_debt':    existing_debt,
        'debt_to_income':   debt_to_income,
        'has_collateral':   has_collateral,
        'loan_approved':    loan_approved
    })

    return df


if __name__ == "__main__":
    print("🏗️  Generating loan dataset...")

    df = generate_loan_dataset(n_samples=2000)

    # Save to data/ folder
    os.makedirs("data", exist_ok=True)
    output_path = "data/loan_data.csv"
    df.to_csv(output_path, index=False)

    print(f"✅ Dataset saved → {output_path}")
    print(f"   Shape     : {df.shape}")
    print(f"   Approved  : {df['loan_approved'].sum()} ({df['loan_approved'].mean()*100:.1f}%)")
    print(f"   Rejected  : {(df['loan_approved']==0).sum()} ({(1-df['loan_approved'].mean())*100:.1f}%)")
    print(f"\n   Sample rows:")
    print(df.head(3).to_string())
