# ============================================================
# rag/retriever.py
#
# PURPOSE: Query the FAISS vector store to find relevant
#          financial knowledge context for a given query.
#
# HOW RAG RETRIEVAL WORKS:
#   1. Convert user query to embedding (same model as indexing)
#   2. Compute similarity between query embedding and all chunks
#   3. Return top-K most similar chunks
#   4. These chunks become "context" for the LLM
# ============================================================

import os
import sys
import pickle
import numpy as np
import faiss
from sentence_transformers import SentenceTransformer

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

FAISS_INDEX_PATH = "models/faiss_index.idx"
CHUNKS_PATH      = "models/chunks.pkl"
EMBEDDING_MODEL  = "all-MiniLM-L6-v2"

# We load these once and cache them (avoids reloading on every query)
_index = None
_chunks = None
_embed_model = None


def _load_resources():
    """Load FAISS index, chunks, and embedding model (cached)."""
    global _index, _chunks, _embed_model

    if _index is None:
        if not os.path.exists(FAISS_INDEX_PATH):
            raise FileNotFoundError(
                "FAISS index not found! Run: python rag/build_vectorstore.py"
            )
        _index = faiss.read_index(FAISS_INDEX_PATH)

    if _chunks is None:
        with open(CHUNKS_PATH, 'rb') as f:
            _chunks = pickle.load(f)

    if _embed_model is None:
        _embed_model = SentenceTransformer(EMBEDDING_MODEL)

    return _index, _chunks, _embed_model


def retrieve_context(query: str, top_k: int = 4) -> list[dict]:
    """
    Retrieve the most relevant knowledge chunks for a query.
    
    Args:
        query  : The question or context to search for
        top_k  : Number of chunks to return (default 4)
    
    Returns:
        List of dicts: [{'text': str, 'score': float, 'rank': int}]
    
    Example:
        query = "low credit score loan rejection"
        → Returns chunks about credit score guidelines and rejection reasons
    """
    index, chunks, embed_model = _load_resources()

    # Embed the query using the same model
    query_embedding = embed_model.encode([query], convert_to_numpy=True)
    faiss.normalize_L2(query_embedding)  # Must normalize for cosine similarity

    # Search for top_k nearest neighbors
    # D = distances (lower L2 = more similar)
    # I = indices of matching chunks
    distances, indices = index.search(query_embedding.astype(np.float32), top_k)

    results = []
    for rank, (dist, idx) in enumerate(zip(distances[0], indices[0])):
        if idx < len(chunks):  # Safety check
            # Convert L2 distance to similarity score (0 to 1)
            similarity = 1 / (1 + dist)
            results.append({
                'text': chunks[idx],
                'score': float(similarity),
                'rank': rank + 1
            })

    return results


def build_context_string(query: str, top_k: int = 4) -> str:
    """
    Build a formatted context string from retrieved chunks.
    This string gets passed to the LLM as background knowledge.
    
    Returns a clean, formatted string of relevant financial guidelines.
    """
    results = retrieve_context(query, top_k=top_k)

    if not results:
        return "No relevant financial guidelines found."

    context_parts = []
    for r in results:
        context_parts.append(f"[Financial Guideline — Relevance: {r['score']:.2f}]\n{r['text']}")

    return "\n\n---\n\n".join(context_parts)


def build_query_from_application(applicant_data: dict, prediction: str) -> str:
    """
    Build a smart query from applicant data + prediction result.
    This query is used to retrieve the most relevant guidelines.
    
    Args:
        applicant_data : Dict with credit_score, debt_to_income, etc.
        prediction     : 'Approved' or 'Rejected'
    """
    credit = applicant_data.get('credit_score', 0)
    dti    = applicant_data.get('debt_to_income', 0)
    emp    = applicant_data.get('employment_type', 'Unknown')

    # Build targeted query based on risk factors
    query_parts = [f"loan {prediction.lower()}"]

    if credit < 580:
        query_parts.append("very poor credit score below 580")
    elif credit < 670:
        query_parts.append("fair credit score")
    elif credit >= 750:
        query_parts.append("excellent credit score above 750")

    if dti > 0.50:
        query_parts.append("very high debt to income ratio above 50%")
    elif dti > 0.43:
        query_parts.append("high debt to income ratio")
    elif dti < 0.30:
        query_parts.append("low debt to income ratio")

    if emp == 'Unemployed':
        query_parts.append("unemployed applicant income requirements")
    elif emp == 'Self-Employed':
        query_parts.append("self employed applicant criteria")

    if prediction == 'Rejected':
        query_parts.append("how to improve loan eligibility rejection reasons")
    else:
        query_parts.append("approved loan interest rate factors")

    return " ".join(query_parts)


if __name__ == "__main__":
    # Test the retriever
    print("🔍 Testing RAG retriever...\n")

    test_query = "low credit score 520 loan rejected high debt to income"
    print(f"Query: '{test_query}'\n")

    results = retrieve_context(test_query, top_k=3)

    for r in results:
        print(f"Rank {r['rank']} (score={r['score']:.3f}):")
        print(f"{r['text'][:200]}...")
        print()
