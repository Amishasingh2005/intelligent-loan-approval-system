# ============================================================
# rag/knowledge_base.py
#
# PURPOSE: Defines the KNOWLEDGE BASE for the RAG system.
#
# This is a collection of financial rules, guidelines, and
# explanations written as plain text documents.
# The RAG system will search these documents to find relevant
# context before generating explanations.
#
# Think of this as the "rulebook" the chatbot reads from.
# ============================================================

# Each item in FINANCIAL_DOCUMENTS is one "document" or "page"
# that will be indexed in the FAISS vector database.

FINANCIAL_DOCUMENTS = [

    # ── CREDIT SCORE GUIDELINES ──────────────────────────────────
    """
    CREDIT SCORE GUIDELINES FOR LOAN APPROVAL

    Credit score (FICO score) is one of the most critical factors in loan decisions.
    It reflects a borrower's credit history, payment reliability, and financial discipline.

    Score Ranges:
    - 800–850 (Exceptional): Lowest risk. Almost always approved. Best interest rates.
    - 740–799 (Very Good): Strong profile. Usually approved with competitive rates.
    - 670–739 (Good): Generally approved. Standard interest rates apply.
    - 580–669 (Fair): May face scrutiny. Higher interest rates, may need co-signer.
    - 300–579 (Poor): High risk. Usually rejected unless strong compensating factors exist.

    Key Rule: A credit score below 620 is typically a red flag for most lenders.
    Applicants with scores below 580 face very high rejection rates.

    Factors that affect credit score:
    - Payment history (35%): Late or missed payments significantly hurt scores.
    - Credit utilization (30%): Using more than 30% of credit limit is risky.
    - Length of credit history (15%): Longer history is better.
    - Credit mix (10%): Having both installment and revolving credit helps.
    - New credit inquiries (10%): Multiple recent applications indicate financial stress.
    """,

    # ── DEBT-TO-INCOME RATIO ──────────────────────────────────────
    """
    DEBT-TO-INCOME RATIO (DTI) — A CRITICAL ELIGIBILITY CRITERION

    Debt-to-Income Ratio = Total Monthly Debt Payments / Gross Monthly Income

    This ratio tells lenders how much of your income is already committed to existing debts.
    A lower DTI means you have more room to handle new loan payments.

    DTI Thresholds:
    - Below 28%: Excellent. Strong approval likelihood. Low financial burden.
    - 28%–36%: Acceptable. Most lenders will approve with good credit score.
    - 37%–43%: Borderline. Some lenders may approve; others may not.
    - 44%–50%: High risk. Approval is unlikely without exceptional credit or collateral.
    - Above 50%: Very high risk. Most lenders will reject the application.

    Key Rule: Most conventional lenders require DTI below 43%.
    FHA loans may allow up to 50% DTI under special circumstances.

    How to improve DTI:
    - Pay off existing debts before applying.
    - Increase income through additional employment.
    - Apply for a smaller loan amount.
    - Avoid taking on new debts before applying.
    """,

    # ── INCOME AND AFFORDABILITY ──────────────────────────────────
    """
    INCOME REQUIREMENTS AND LOAN AFFORDABILITY

    Lenders assess whether an applicant's income is sufficient to service
    the monthly loan payments without financial strain.

    Key Affordability Metrics:

    1. Income-to-Loan Ratio:
       - Recommended: Annual income should be at least 3–4x the loan amount.
       - Example: For a $150,000 loan, income should ideally be $50,000+.
       - Very high loan-to-income ratios (above 5x) typically lead to rejection.

    2. Monthly Payment Coverage:
       - Monthly income should cover at least 3x the estimated monthly payment.
       - This ensures the borrower has money left for living expenses.

    3. Employment Stability:
       - Employed (salaried): Best profile. Stable, predictable income.
       - Self-Employed: Higher scrutiny. Must show 2+ years of consistent income.
       - Unemployed: Almost always rejected unless supported by assets/collateral.
       - Years of employment matter: 2+ years at current job is a positive signal.

    4. Income Sources:
       - Primary employment income is most favorably viewed.
       - Rental income, investment income can supplement but not replace.
       - Benefits or welfare income may not be fully counted by some lenders.
    """,

    # ── COLLATERAL AND SECURITY ──────────────────────────────────
    """
    COLLATERAL AND LOAN SECURITY

    Collateral is an asset pledged by the borrower as security for the loan.
    If the borrower defaults, the lender can seize the collateral to recover losses.

    Types of Collateral:
    - Real Estate (home, land): Most accepted. High value, easy to liquidate.
    - Vehicles: Accepted for auto loans. Depreciates over time.
    - Fixed Deposits / Savings: Highly liquid, strongly preferred.
    - Investments (stocks, bonds): Accepted but volatile in value.
    - Equipment / Business Assets: For business loans.

    Impact on Loan Decision:
    - Having collateral significantly improves approval chances.
    - Allows lenders to approve higher loan amounts.
    - Results in lower interest rates due to reduced lender risk.
    - Can compensate for a slightly lower credit score.

    Unsecured Loans (no collateral):
    - Higher interest rates to compensate for increased lender risk.
    - Require stronger credit score and income profile.
    - Typically have lower maximum loan amounts.
    - Examples: Personal loans, credit cards, student loans.
    """,

    # ── LOAN REJECTION REASONS ────────────────────────────────────
    """
    COMMON REASONS FOR LOAN REJECTION

    Understanding why loans get rejected helps applicants improve their profile.

    Top Rejection Reasons:

    1. Poor Credit Score (below 580):
       Indicates history of missed payments, defaults, or high debt utilization.
       Fix: Pay bills on time, reduce credit utilization, avoid new inquiries.

    2. High Debt-to-Income Ratio (above 43%):
       Borrower already has too much existing debt relative to income.
       Fix: Pay down existing debts, increase income, apply for smaller loan.

    3. Insufficient Income:
       Requested loan amount too large relative to income.
       Fix: Apply for smaller amount, add co-borrower, increase income.

    4. Unemployment or Unstable Employment:
       Lender cannot verify consistent income to service payments.
       Fix: Secure employment, wait 6-12 months, provide alternative income proof.

    5. Short Credit History:
       Not enough history for lender to assess creditworthiness.
       Fix: Build credit with secured credit card, become authorized user.

    6. Recent Bankruptcies or Foreclosures:
       Major negative events on credit report.
       Fix: Wait required period (typically 2-7 years) and rebuild credit.

    7. Too Many Recent Hard Inquiries:
       Multiple loan applications in short period signals financial desperation.
       Fix: Limit applications, use soft inquiry pre-qualification tools.

    8. Loan Purpose Not Aligned with Lender Policy:
       Some lenders restrict loan purposes (e.g., gambling, speculative investments).
    """,

    # ── LOAN APPROVAL FACTORS ─────────────────────────────────────
    """
    FACTORS THAT STRONGLY SUPPORT LOAN APPROVAL

    Positive signals that increase the likelihood of loan approval:

    1. High Credit Score (720+):
       Demonstrates financial responsibility and reliable payment history.
       Results in better rates and higher approval likelihood.

    2. Low Debt-to-Income Ratio (below 30%):
       Shows borrower is not overburdened with existing debts.
       Lender is confident in repayment capacity.

    3. Stable Long-Term Employment (3+ years):
       Consistent income stream reduces default risk.
       Salaried employment preferred; self-employment with 2+ year history acceptable.

    4. Adequate Income for Loan Size:
       Monthly payment does not exceed 28-30% of gross monthly income.
       Total debt payments do not exceed 36-43% of gross monthly income.

    5. Collateral / Security:
       Reduces lender's risk exposure significantly.
       Enables higher loan amounts and better interest rates.

    6. Healthy Down Payment:
       For mortgages: 20%+ down payment avoids PMI and shows commitment.
       Reduces overall loan amount, improving all ratios.

    7. Clean Credit History:
       No bankruptcies, foreclosures, or recent late payments.
       Consistent on-time payment record over several years.

    8. Reasonable Loan Purpose:
       Home purchase, education, medical expenses are viewed favorably.
       Business expansion with clear plan is also viewed positively.
    """,

    # ── INTEREST RATES ────────────────────────────────────────────
    """
    INTEREST RATES AND HOW THEY ARE DETERMINED

    Interest rates on loans vary based on risk assessment of the borrower.
    Higher-risk borrowers pay more; lower-risk borrowers get better rates.

    Typical Rate Ranges (approximate, as of 2024):
    - Personal Loans: 7% to 36% APR
    - Mortgages (30-year fixed): 6% to 9% APR
    - Auto Loans: 5% to 20% APR
    - Credit Cards: 15% to 30% APR

    Factors Affecting Your Rate:
    - Credit Score: Primary driver. 750+ gets best rates; below 650 gets worst.
    - Loan Term: Longer terms usually mean higher rates (more risk for lender).
    - Loan Type: Secured (collateral) = lower rate; Unsecured = higher rate.
    - Market Conditions: Federal Reserve rate decisions affect all loan rates.
    - Income Stability: Self-employed often pays 0.5-1% more than salaried.
    - Loan Amount: Very small or very large loans may carry higher rates.

    Example: A borrower with 800 credit score might get 7% rate while someone
    with 600 credit score gets 18% rate for the same loan amount.
    """,

    # ── FINANCIAL ADVISORY ────────────────────────────────────────
    """
    FINANCIAL ADVISORY: IMPROVING YOUR LOAN ELIGIBILITY

    If your loan application was rejected or you want to improve chances:

    Short-Term Actions (0-6 months):
    - Pay all bills on time immediately.
    - Pay down credit card balances to below 30% utilization.
    - Do not apply for new credit cards or loans.
    - Dispute any errors on your credit report.
    - Consider a secured loan or credit-builder loan.

    Medium-Term Actions (6-18 months):
    - Continue building credit through on-time payments.
    - Reduce existing debt systematically.
    - Build emergency savings to show financial stability.
    - Increase income through additional work or promotion.
    - Consider a co-signer with strong credit for your next application.

    Long-Term Actions (18+ months):
    - Maintain consistent employment history.
    - Build a diversified credit profile (installment + revolving).
    - Save for a larger down payment (for mortgage loans).
    - Keep DTI below 30% at all times.
    - Monitor credit regularly (AnnualCreditReport.com — free in the US).

    Remember: Loan rejection is not permanent. Most factors are improvable
    with time, discipline, and the right financial strategy.
    """
]


def get_all_documents() -> list[str]:
    """Return all financial knowledge documents."""
    return FINANCIAL_DOCUMENTS


def get_document_count() -> int:
    """Return number of documents in the knowledge base."""
    return len(FINANCIAL_DOCUMENTS)


if __name__ == "__main__":
    docs = get_all_documents()
    print(f"📚 Knowledge base contains {len(docs)} documents")
    for i, doc in enumerate(docs):
        first_line = doc.strip().split('\n')[0]
        print(f"   Doc {i+1}: {first_line}")
