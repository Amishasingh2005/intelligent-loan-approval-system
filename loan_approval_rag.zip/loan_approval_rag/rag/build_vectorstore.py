# ============================================================
# rag/build_vectorstore.py
#
# PURPOSE: Build the FAISS vector database from our knowledge base.
#
# STEPS:
#   1. Load text documents from knowledge_base.py
#   2. Split them into smaller chunks (chunking)
#   3. Convert chunks to embeddings (numerical vectors)
#   4. Store embeddings in FAISS vector database
#   5. Save the FAISS index to disk for reuse
#
# WHAT IS AN EMBEDDING?
#   An embedding is a list of numbers (e.g. 384 numbers) that
#   represents the MEANING of a piece of text.
#   Similar texts produce similar embeddings.
#   FAISS finds the most similar embeddings to a user query.
# ============================================================

import os
import sys
import pickle
import numpy as np
import faiss
from sentence_transformers import SentenceTransformer

# Add project root to path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from rag.knowledge_base import get_all_documents


# ── CONFIGURATION ─────────────────────────────────────────────────
CHUNK_SIZE = 400        # Max characters per chunk
CHUNK_OVERLAP = 80      # Characters overlapping between consecutive chunks
                        # (overlap ensures context isn't lost at chunk boundaries)

EMBEDDING_MODEL = "all-MiniLM-L6-v2"   # Fast, lightweight, good quality
                                         # 384-dimensional embeddings
                                         # ~80MB download on first run

FAISS_INDEX_PATH = "models/faiss_index.idx"
CHUNKS_PATH      = "models/chunks.pkl"


def chunk_text(text: str, chunk_size: int = CHUNK_SIZE, overlap: int = CHUNK_OVERLAP) -> list[str]:
    """
    Split a long text into smaller overlapping chunks.
    
    WHY CHUNK?
    - LLMs have token limits — can't read very long documents at once
    - Smaller chunks = more precise retrieval
    - Overlap ensures sentences at boundaries aren't cut in half
    
    Example (chunk_size=20, overlap=5):
    Text: "Hello world this is a test sentence about loans"
    Chunk 1: "Hello world this is a"
    Chunk 2: "is a test sentence ab"  ← overlaps 5 chars with chunk 1
    Chunk 3: "ce ab loans"
    """
    chunks = []
    start = 0
    text = text.strip()

    while start < len(text):
        end = start + chunk_size

        # If not at end of text, try to break at a sentence boundary
        if end < len(text):
            # Look backwards for a period or newline to break cleanly
            break_point = text.rfind('.', start, end)
            newline_point = text.rfind('\n', start, end)
            boundary = max(break_point, newline_point)

            if boundary > start + chunk_size // 2:
                end = boundary + 1  # Include the period/newline

        chunk = text[start:end].strip()
        if chunk:  # Only add non-empty chunks
            chunks.append(chunk)

        start = end - overlap  # Move forward with overlap

    return chunks


def build_vectorstore():
    """
    Main function: build and save the FAISS vector store.
    """
    print("=" * 55)
    print("  🔍 BUILDING RAG VECTOR STORE")
    print("=" * 55)

    # ── Step 1: Load documents ─────────────────────────────────
    print("\n📚 Step 1: Loading knowledge base documents...")
    documents = get_all_documents()
    print(f"   Loaded {len(documents)} documents")

    # ── Step 2: Chunk documents ────────────────────────────────
    print(f"\n✂️  Step 2: Chunking documents (size={CHUNK_SIZE}, overlap={CHUNK_OVERLAP})...")
    all_chunks = []

    for i, doc in enumerate(documents):
        chunks = chunk_text(doc, CHUNK_SIZE, CHUNK_OVERLAP)
        all_chunks.extend(chunks)
        print(f"   Doc {i+1}: {len(chunks)} chunks")

    print(f"\n   Total chunks: {len(all_chunks)}")

    # ── Step 3: Load embedding model ──────────────────────────
    print(f"\n🤖 Step 3: Loading embedding model '{EMBEDDING_MODEL}'...")
    print("   (First run will download ~80MB — subsequent runs are instant)")
    model = SentenceTransformer(EMBEDDING_MODEL)
    print("   ✅ Model loaded!")

    # ── Step 4: Create embeddings ─────────────────────────────
    print(f"\n🧮 Step 4: Creating embeddings for {len(all_chunks)} chunks...")
    embeddings = model.encode(
        all_chunks,
        show_progress_bar=True,
        batch_size=32,
        convert_to_numpy=True
    )
    print(f"   Embedding shape: {embeddings.shape}")  # (n_chunks, 384)
    print(f"   Each embedding: {embeddings.shape[1]}-dimensional vector")

    # ── Step 5: Build FAISS index ─────────────────────────────
    print(f"\n📦 Step 5: Building FAISS index...")

    dimension = embeddings.shape[1]  # 384 for MiniLM

    # IndexFlatL2: Exact L2 (Euclidean) distance search
    # For production with millions of docs, use IndexIVFFlat or HNSW
    index = faiss.IndexFlatL2(dimension)

    # Normalize embeddings for cosine similarity
    faiss.normalize_L2(embeddings)

    # Add all embeddings to the index
    index.add(embeddings.astype(np.float32))

    print(f"   ✅ FAISS index built with {index.ntotal} vectors")

    # ── Step 6: Save to disk ──────────────────────────────────
    print(f"\n💾 Step 6: Saving index to disk...")
    os.makedirs("models", exist_ok=True)

    # Save FAISS index
    faiss.write_index(index, FAISS_INDEX_PATH)

    # Save chunks (needed to retrieve original text for a match)
    with open(CHUNKS_PATH, 'wb') as f:
        pickle.dump(all_chunks, f)

    print(f"   ✅ FAISS index saved → {FAISS_INDEX_PATH}")
    print(f"   ✅ Chunks saved      → {CHUNKS_PATH}")
    print(f"\n🎉 Vector store build complete!")

    return index, all_chunks, model


if __name__ == "__main__":
    build_vectorstore()
